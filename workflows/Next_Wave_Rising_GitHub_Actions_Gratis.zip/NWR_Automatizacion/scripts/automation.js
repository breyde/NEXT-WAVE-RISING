const admin = require('firebase-admin');

if (!process.env.FIREBASE_SERVICE_ACCOUNT) {
  throw new Error('Falta el secreto FIREBASE_SERVICE_ACCOUNT de GitHub Actions.');
}
admin.initializeApp({
  credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT))
});
const logger = console;
const db = admin.firestore();
const TZ = 'Europe/Madrid';
const REGION = 'europe-west1';
const MAX_BATCH_WRITES = 450;
const BACKUP_MAX_BYTES = 950000; // Leave margin below Firestore's 1 MiB document limit.

function madridParts(date = new Date()) {
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-GB', {
    timeZone: TZ,
    year: 'numeric', month: '2-digit', day: '2-digit',
    weekday: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit',
    hour12: false
  }).formatToParts(date).map(p => [p.type, p.value]));
  return {
    year: Number(parts.year), month: Number(parts.month), day: Number(parts.day),
    weekday: parts.weekday, hour: Number(parts.hour), minute: Number(parts.minute),
    second: Number(parts.second)
  };
}

function madridDateKey(date = new Date()) {
  const p = madridParts(date);
  return `${p.year}-${String(p.month).padStart(2, '0')}-${String(p.day).padStart(2, '0')}`;
}

function madridDateLabel(date = new Date()) {
  return new Intl.DateTimeFormat('es-ES', { timeZone: TZ }).format(date);
}

function previousDateKey(dateKey) {
  const [y, m, d] = dateKey.split('-').map(Number);
  const date = new Date(Date.UTC(y, m - 1, d - 1, 12));
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
}

function millis(value) {
  if (value && typeof value.toMillis === 'function') return value.toMillis();
  if (typeof value === 'number') return value;
  if (value instanceof Date) return value.getTime();
  return 0;
}

function dataWithId(doc) {
  return { id: doc.id, ...doc.data() };
}

async function readCollection(name) {
  const snap = await db.collection(name).get();
  return snap.docs.map(dataWithId);
}

async function saveOrReadSystemBackup(dateKey, label, forcedBackupId = null) {
  const [activeTracks, weeklyTracks, monthlyTracks, annualTracks, countriesList, votersLog] = await Promise.all([
    readCollection('active_list'),
    readCollection('submissions'),
    readCollection('monthly_list'),
    readCollection('annual_list'),
    readCollection('artist_countries'),
    readCollection('voters_log')
  ]);

  const date = new Date(`${dateKey}T12:00:00+01:00`);
  const dateOnly = madridDateLabel(date);
  const backupId = forcedBackupId || `sys_backup_${dateOnly.replace(/\//g, '-')}`;
  const ref = db.collection('backups').doc(backupId);
  const existing = await ref.get();
  if (existing.exists) {
    const old = existing.data();
    if (!Array.isArray(old.activeTracks) || !Array.isArray(old.weeklyTracks) || !Array.isArray(old.monthlyTracks) || !Array.isArray(old.annualTracks)) {
      throw new Error('Existe una copia previa incompleta; se cancela la rotación para proteger las listas.');
    }
    return { ref, payload: old, created: false };
  }

  const payload = {
    scope: 'all',
    edition: label || `Copia de sistema - ${dateOnly}`,
    dateString: `${dateOnly} 23:59 (Europe/Madrid)`,
    dateOnly,
    timestamp: Date.now(),
    activeCount: activeTracks.length,
    weeklyCount: weeklyTracks.length,
    monthlyCount: monthlyTracks.length,
    annualCount: annualTracks.length,
    countriesCount: countriesList.length,
    votersCount: votersLog.length,
    activeTracks, weeklyTracks, monthlyTracks, annualTracks, countriesList, votersLog
  };
  const bytes = Buffer.byteLength(JSON.stringify(payload), 'utf8');
  if (bytes > BACKUP_MAX_BYTES) {
    throw new Error(`La copia completa supera el límite seguro de Firestore (${bytes} bytes). No se han modificado las listas.`);
  }

  await ref.create(payload);
  const verify = await ref.get();
  if (!verify.exists) throw new Error('No se pudo verificar la copia de seguridad. Rotación cancelada.');
  const saved = verify.data();
  const valid = saved.activeTracks?.length === activeTracks.length &&
    saved.weeklyTracks?.length === weeklyTracks.length &&
    saved.monthlyTracks?.length === monthlyTracks.length &&
    saved.annualTracks?.length === annualTracks.length &&
    saved.countriesList?.length === countriesList.length &&
    saved.votersLog?.length === votersLog.length;
  if (!valid) throw new Error('La verificación de la copia no coincide con los datos originales. Rotación cancelada.');
  return { ref, payload: saved, created: true };
}

async function replaceCollection(name, records) {
  const col = db.collection(name);
  const current = await col.get();
  for (let i = 0; i < current.docs.length; i += MAX_BATCH_WRITES) {
    const batch = db.batch();
    current.docs.slice(i, i + MAX_BATCH_WRITES).forEach(doc => batch.delete(doc.ref));
    await batch.commit();
  }
  for (let i = 0; i < records.length; i += MAX_BATCH_WRITES) {
    const batch = db.batch();
    records.slice(i, i + MAX_BATCH_WRITES).forEach(record => {
      const { id, ...data } = record;
      batch.set(col.doc(String(id)), data);
    });
    await batch.commit();
  }
}

async function deleteKnownDocuments(collectionName, records) {
  const col = db.collection(collectionName);
  const ids = [...new Set((records || []).map(x => x.id).filter(Boolean))];
  for (let i = 0; i < ids.length; i += MAX_BATCH_WRITES) {
    const batch = db.batch();
    ids.slice(i, i + MAX_BATCH_WRITES).forEach(id => batch.delete(col.doc(String(id))));
    await batch.commit();
  }
}

function stableId(prefix, dateKey, originalId) {
  const encoded = Buffer.from(String(originalId || 'unknown'), 'utf8').toString('hex').slice(0, 80);
  return `${prefix}_${dateKey.replace(/-/g, '')}_${encoded}`;
}

function monthlyBlockKey(track) {
  if (track.blockId) return String(track.blockId);
  // Older records have no blockId. Their Madrid calendar date groups tracks
  // added by the same historical weekly rotation into one legacy block.
  const ts = millis(track.timestamp);
  return ts ? `legacy-${madridDateKey(new Date(ts))}` : 'legacy-undated';
}

async function acquireRun(runRef) {
  return db.runTransaction(async tx => {
    const snap = await tx.get(runRef);
    const data = snap.exists ? snap.data() : {};
    if (data.status === 'complete') return false;
    const now = Date.now();
    if (data.status === 'running' && Number(data.leaseUntil || 0) > now) return false;
    tx.set(runRef, { status: 'running', startedAt: now, leaseUntil: now + 12 * 60 * 1000, attempts: Number(data.attempts || 0) + 1 }, { merge: true });
    return true;
  });
}

async function createAutomationInboxMessage(id, title, message, extra = {}) {
  // Uses the existing admin inbox collection and a stable document ID so retries
  // cannot create duplicate notifications.
  await db.collection('contact_messages').doc(id).set({
    name: title,
    email: 'Sistema automático',
    message,
    timestamp: Date.now(),
    dateString: `${madridDateLabel(new Date())} ${new Intl.DateTimeFormat('es-ES', { timeZone: TZ, hour: '2-digit', minute: '2-digit' }).format(new Date())}`,
    read: false,
    system: true,
    type: 'automation',
    ...extra
  }, { merge: true });
}

async function closeVotingForDate(dateKey) {
  const runRef = db.collection('automation_runs').doc(`vote_close_${dateKey}`);
  const claimed = await acquireRun(runRef);
  if (!claimed) return;
  try {
    await db.collection('settings').doc('activeEdition').set({
      votingActive: false,
      votingClosedAt: Date.now(),
      votingClosedFor: dateKey
    }, { merge: true });
    await runRef.set({ status: 'complete', completedAt: Date.now(), timezone: TZ }, { merge: true });
    logger.info(`Votación cerrada automáticamente para ${dateKey} (${TZ}).`);
  } catch (error) {
    await runRef.set({ status: 'failed', error: String(error.message || error), leaseUntil: Date.now() + 15 * 60 * 1000 }, { merge: true });
    throw error;
  }
}

async function rotateWeeklyLists(dateKey) {
  const runRef = db.collection('automation_runs').doc(`weekly_rotation_${dateKey}`);
  const claimed = await acquireRun(runRef);
  if (!claimed) return;
  try {
    // If the scheduled 22:00 invocation was delayed, enforce closure before rotating.
    await closeVotingForDate(dateKey);
    // Always capture and verify the complete pre-rotation state before any mutation.
    const { payload: backup } = await saveOrReadSystemBackup(dateKey, `Copia de sistema - ${madridDateLabel(new Date())}`);
    const oldActive = (Array.isArray(backup.activeTracks) ? backup.activeTracks : []).sort((a, b) => millis(a.timestamp) - millis(b.timestamp));
    const oldQueue = Array.isArray(backup.weeklyTracks) ? backup.weeklyTracks : [];
    const monthly = Array.isArray(backup.monthlyTracks) ? backup.monthlyTracks.map(x => ({ ...x })) : [];
    const annual = Array.isArray(backup.annualTracks) ? backup.annualTracks.map(x => ({ ...x })) : [];

    let winner = null;
    for (const track of oldActive) {
      if (!winner || Number(track.votes || 0) > Number(winner.votes || 0)) winner = track;
    }
    if (winner && Number(winner.votes || 0) <= 0) winner = null;

    const blockId = `weekly-${dateKey}`;
    const rotationTimestamp = Date.now();
    const monthlyAdditions = oldActive.map((track, index) => ({
      id: stableId('monthly', dateKey, track.id || `${index}-${track.url || track.title}`),
      artist: track.artist || '', title: track.title || '', url: track.url || '',
      timestamp: rotationTimestamp + index, blockId, blockDate: dateKey
    }));
    let monthlyNext = [...monthly, ...monthlyAdditions];

    // Keep four weekly blocks (not four individual songs). Legacy blocks are
    // grouped by the Madrid date on which their records were originally added.
    const groups = new Map();
    for (const track of monthlyNext) {
      const key = monthlyBlockKey(track);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(track);
    }
    const orderedGroups = [...groups.entries()].sort((a, b) => {
      const ta = Math.min(...a[1].map(x => millis(x.timestamp) || 0));
      const tb = Math.min(...b[1].map(x => millis(x.timestamp) || 0));
      return ta - tb;
    });
    while (orderedGroups.length > 4) {
      const [, expired] = orderedGroups.shift();
      expired.forEach((track, index) => annual.push({
        ...track,
        id: stableId('annual', dateKey, track.id || `${index}-${track.url || track.title}`),
        timestamp: Date.now(),
        archivedFromBlock: monthlyBlockKey(track)
      }));
      const expiredIds = new Set(expired.map(x => x.id));
      monthlyNext = monthlyNext.filter(x => !expiredIds.has(x.id));
    }

    const activeNext = oldQueue.map((track, index) => ({
      id: stableId('active', dateKey, track.id || `${index}-${track.url || track.title}`),
      artist: track.artist || '', title: track.title || '', url: track.url || '', email: track.email || '',
      timestamp: Date.now() + index, dateString: madridDateLabel(new Date()), votes: 0, voters: []
    }));
    if (winner && !activeNext.some(x => x.url && x.url === winner.url)) {
      activeNext.push({
        id: stableId('featured', dateKey, winner.id || winner.url || winner.title),
        artist: winner.artist || '', title: winner.title || '', url: winner.url || '', email: winner.email || '',
        timestamp: Date.now() + activeNext.length, dateString: madridDateLabel(new Date()), votes: 0, voters: [], featuredWinner: true
      });
    }

    // Replace target collections from the verified snapshot. Stable IDs make
    // retries safe if a previous execution stopped halfway through.
    await replaceCollection('monthly_list', monthlyNext);
    await replaceCollection('annual_list', annual);
    await replaceCollection('active_list', activeNext);
    await deleteKnownDocuments('submissions', oldQueue);
    await replaceCollection('voters_log', []);

    const editionUpdate = { votingActive: true, votingOpenedAt: Date.now(), votingOpenedFor: dateKey };
    if (winner?.url) editionUpdate.trackUrl = winner.url;
    await db.collection('settings').doc('activeEdition').set(editionUpdate, { merge: true });
    await createAutomationInboxMessage(
      `system_weekly_rotation_${dateKey}`,
      'Next Wave Rising — Rotación semanal completada',
      `La rotación semanal del ${dateKey} se ha completado automáticamente.\n\nTemas en la nueva lista activa: ${activeNext.length}.\nTemas trasladados a la mensual: ${monthlyAdditions.length}.\nBloques mensuales conservados: ${orderedGroups.length}.\nTemas en la anual: ${annual.length}.\nGanador destacado: ${winner ? `${winner.artist || 'Artista'} — ${winner.title || 'Tema'} (${Number(winner.votes || 0)} votos)` : 'Sin ganador (no hubo votos válidos)'}.\n\nCopia de seguridad verificada antes de modificar las listas.`,
      { automationId: `weekly_rotation_${dateKey}`, winner: winner ? { artist: winner.artist || '', title: winner.title || '', votes: Number(winner.votes || 0) } : null }
    );
    await runRef.set({
      status: 'complete', completedAt: Date.now(), timezone: TZ,
      backupId: `sys_backup_${madridDateLabel(new Date(`${dateKey}T12:00:00+01:00`)).replace(/\//g, '-')}`,
      counts: { previousActive: oldActive.length, previousQueue: oldQueue.length, newActive: activeNext.length, monthlyBlocks: orderedGroups.length, monthlyTracks: monthlyNext.length, annualTracks: annual.length },
      winner: winner ? { artist: winner.artist || '', title: winner.title || '', votes: Number(winner.votes || 0) } : null
    }, { merge: true });
    logger.info(`Rotación semanal completada: ${dateKey}.`, { active: activeNext.length, monthly: monthlyNext.length, annual: annual.length });
  } catch (error) {
    await runRef.set({ status: 'failed', error: String(error.message || error), leaseUntil: Date.now() + 15 * 60 * 1000, failedAt: Date.now() }, { merge: true });
    logger.error(`Falló la rotación semanal ${dateKey}; las siguientes comprobaciones volverán a intentarlo.`, error);
    throw error;
  }
}

async function rolloverYearToAnnual(year) {
  const runRef = db.collection('automation_runs').doc(`annual_rollover_${year}`);
  const claimed = await acquireRun(runRef);
  if (!claimed) return;
  try {
    const dateKey = `${year}-12-31`;
    const { payload: backup } = await saveOrReadSystemBackup(dateKey, `Copia anual de cierre - ${year}`, `year_end_backup_${year}`);
    const monthly = Array.isArray(backup.monthlyTracks) ? backup.monthlyTracks : [];
    const annual = Array.isArray(backup.annualTracks) ? backup.annualTracks : [];
    const annualNext = [...annual];
    const seen = new Set(annual.map(x => x.url || `${x.artist}|${x.title}`));
    monthly.forEach((track, index) => {
      const key = track.url || `${track.artist}|${track.title}`;
      // Do not duplicate a track already present in the annual archive.
      if (!seen.has(key)) {
        seen.add(key);
        annualNext.push({
          ...track,
          id: stableId('yearend', String(year), track.id || `${index}-${key}`),
          timestamp: Date.now(), archivedFrom: `monthly-${year}`
        });
      }
    });
    await replaceCollection('annual_list', annualNext);
    await replaceCollection('monthly_list', []);
    await createAutomationInboxMessage(
      `system_annual_rollover_${year}`,
      `Next Wave Rising — Cierre anual ${year} completado`,
      `El cierre anual de ${year} se ha completado automáticamente.\n\nTemas trasladados desde la mensual: ${monthly.length}.\nTemas archivados en la anual: ${annualNext.length}.\nLa copia de seguridad anual se verificó antes del traslado.`,
      { automationId: `annual_rollover_${year}`, year, movedTracks: monthly.length }
    );
    await runRef.set({ status: 'complete', completedAt: Date.now(), year, movedTracks: monthly.length, annualTracks: annualNext.length, timezone: TZ }, { merge: true });
    logger.info(`Cierre anual ${year}: ${monthly.length} temas enviados a la lista anual.`);
  } catch (error) {
    await runRef.set({ status: 'failed', error: String(error.message || error), leaseUntil: Date.now() + 15 * 60 * 1000, failedAt: Date.now() }, { merge: true });
    logger.error(`Falló el cierre anual ${year}; se reintentará automáticamente.`, error);
    throw error;
  }
}

async function schedulerTick() {
  const p = madridParts();
  const today = madridDateKey();
  const weekdayIndex = ({ Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 })[p.weekday];

  // Close voting at/after Thursday 22:00 Madrid time. If a scheduled run was
  // delayed, the weekly rotation also closes the corresponding edition first.
  if (p.weekday === 'Thu' && p.hour >= 22) {
    await closeVotingForDate(today);
  }

  // Find the most recent Thursday. Before Thursday 23:59, target the previous
  // week's Thursday; from Friday onward, target the Thursday just passed.
  let daysSinceThursday = (weekdayIndex - 4 + 7) % 7;
  if (p.weekday === 'Thu' && (p.hour < 23 || (p.hour === 23 && p.minute < 59))) {
    daysSinceThursday = 7;
  }
  const [yy, mm, dd] = today.split('-').map(Number);
  const targetDate = new Date(Date.UTC(yy, mm - 1, dd - daysSinceThursday, 12));
  const targetKey = `${targetDate.getUTCFullYear()}-${String(targetDate.getUTCMonth() + 1).padStart(2, '0')}-${String(targetDate.getUTCDate()).padStart(2, '0')}`;

  // Keep retrying an incomplete Thursday rotation on later days. The stable
  // run ID and backup make retries idempotent and prevent a second rotation.
  if (!(p.weekday === 'Thu' && daysSinceThursday === 7)) {
    const runRef = db.collection('automation_runs').doc(`weekly_rotation_${targetKey}`);
    const runSnap = await runRef.get();
    if (!runSnap.exists || runSnap.data().status !== 'complete') {
      await rotateWeeklyLists(targetKey);
    }
  }

  // Retry the previous year's rollover throughout January until
  // its stable run record reports completion.
  if (p.month === 1) {
    await rolloverYearToAnnual(p.year - 1);
  }
}

schedulerTick().then(() => {
  logger.info('Next Wave Rising: comprobación automática finalizada.');
  process.exit(0);
}).catch(error => {
  logger.error('Next Wave Rising: error en la comprobación automática.', error);
  process.exit(1);
});
